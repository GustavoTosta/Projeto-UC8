﻿namespace Projeto_Integrador
{
    partial class MDI_Funcionario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDI_Funcionario));
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.grupo_1 = new System.Windows.Forms.GroupBox();
            this.pic_funcionario = new System.Windows.Forms.PictureBox();
            this.lbl_Meta = new System.Windows.Forms.Label();
            this.pic2_estatisticas = new System.Windows.Forms.PictureBox();
            this.lbl_funcionario = new System.Windows.Forms.Label();
            this.bto_voltar = new System.Windows.Forms.Button();
            this.grupo_1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_funcionario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2_estatisticas)).BeginInit();
            this.SuspendLayout();
            // 
            // grupo_1
            // 
            this.grupo_1.Controls.Add(this.bto_voltar);
            this.grupo_1.Controls.Add(this.pic_funcionario);
            this.grupo_1.Controls.Add(this.lbl_Meta);
            this.grupo_1.Controls.Add(this.pic2_estatisticas);
            this.grupo_1.Controls.Add(this.lbl_funcionario);
            this.grupo_1.Location = new System.Drawing.Point(-15, -29);
            this.grupo_1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grupo_1.Name = "grupo_1";
            this.grupo_1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grupo_1.Size = new System.Drawing.Size(769, 492);
            this.grupo_1.TabIndex = 16;
            this.grupo_1.TabStop = false;
            // 
            // pic_funcionario
            // 
            this.pic_funcionario.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic_funcionario.Image = ((System.Drawing.Image)(resources.GetObject("pic_funcionario.Image")));
            this.pic_funcionario.Location = new System.Drawing.Point(179, 145);
            this.pic_funcionario.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pic_funcionario.Name = "pic_funcionario";
            this.pic_funcionario.Size = new System.Drawing.Size(174, 168);
            this.pic_funcionario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_funcionario.TabIndex = 4;
            this.pic_funcionario.TabStop = false;
            this.pic_funcionario.Click += new System.EventHandler(this.pic_funcionario_Click);
            // 
            // lbl_Meta
            // 
            this.lbl_Meta.AutoSize = true;
            this.lbl_Meta.Location = new System.Drawing.Point(439, 319);
            this.lbl_Meta.Name = "lbl_Meta";
            this.lbl_Meta.Size = new System.Drawing.Size(123, 20);
            this.lbl_Meta.TabIndex = 12;
            this.lbl_Meta.Text = "Criador de metas";
            // 
            // pic2_estatisticas
            // 
            this.pic2_estatisticas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pic2_estatisticas.Image = ((System.Drawing.Image)(resources.GetObject("pic2_estatisticas.Image")));
            this.pic2_estatisticas.Location = new System.Drawing.Point(415, 145);
            this.pic2_estatisticas.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pic2_estatisticas.Name = "pic2_estatisticas";
            this.pic2_estatisticas.Size = new System.Drawing.Size(173, 168);
            this.pic2_estatisticas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic2_estatisticas.TabIndex = 8;
            this.pic2_estatisticas.TabStop = false;
            this.pic2_estatisticas.Click += new System.EventHandler(this.pic2_estatisticas_Click);
            // 
            // lbl_funcionario
            // 
            this.lbl_funcionario.AutoSize = true;
            this.lbl_funcionario.Location = new System.Drawing.Point(179, 319);
            this.lbl_funcionario.Name = "lbl_funcionario";
            this.lbl_funcionario.Size = new System.Drawing.Size(174, 20);
            this.lbl_funcionario.TabIndex = 11;
            this.lbl_funcionario.Text = "Cadastro de funcionários";
            // 
            // bto_voltar
            // 
            this.bto_voltar.Location = new System.Drawing.Point(27, 430);
            this.bto_voltar.Name = "bto_voltar";
            this.bto_voltar.Size = new System.Drawing.Size(107, 40);
            this.bto_voltar.TabIndex = 13;
            this.bto_voltar.Text = "Voltar";
            this.bto_voltar.UseVisualStyleBackColor = true;
            this.bto_voltar.Click += new System.EventHandler(this.bto_voltar_Click);
            // 
            // MDI_Funcionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 453);
            this.Controls.Add(this.grupo_1);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "MDI_Funcionario";
            this.Text = "Escolha de tela funcionário";
            this.grupo_1.ResumeLayout(false);
            this.grupo_1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_funcionario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2_estatisticas)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion
        private System.Windows.Forms.ToolTip toolTip;
        private GroupBox grupo_1;
        private PictureBox pic_funcionario;
        private Label lbl_Meta;
        private PictureBox pic2_estatisticas;
        private Label lbl_funcionario;
        private Button bto_voltar;
    }
}



