﻿using frmProjeto_Integrador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Integrador
{
    public partial class MDI_Funcionario : Form
    {

        public MDI_Funcionario()
        {
            InitializeComponent();
        }

        private void pic_funcionario_Click(object sender, EventArgs e)
        {
            frm_funcionario funcionario = new frm_funcionario();
            funcionario.Show();
            this.Hide();
        }

        private void bto_voltar_Click(object sender, EventArgs e)
        {
            MDITelaIncial tela = new MDITelaIncial();
            tela.Show();
            this.Hide();
        }

        private void pic2_estatisticas_Click(object sender, EventArgs e)
        {
            Frm_Meta meta = new Frm_Meta();
            meta.Show();
            this.Hide();
        }
    }
}
