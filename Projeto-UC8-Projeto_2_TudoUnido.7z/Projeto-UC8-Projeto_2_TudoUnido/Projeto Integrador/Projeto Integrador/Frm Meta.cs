﻿using Projeto_Integrador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmProjeto_Integrador
{
    public partial class Frm_Meta : Form
    {
        public Frm_Meta()
        {
            InitializeComponent();
        }

        string Conexao = frm_produto.Conexao;

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txt_obs_TextChanged(object sender, EventArgs e)
        {

        }

        private void bto_pesquisa_Click(object sender, EventArgs e)
        {

        }

        private void bto_sair_Click(object sender, EventArgs e)
        {
            MDITelaIncial tela = new MDITelaIncial();
            tela.Show();
            this.Hide();
        }

        private void bto_cadastrar_Click(object sender, EventArgs e)
        {

            string Cadastro = "Insert into meta (nome_meta, descricao_meta, data_metas_incio, data_meta_fim, status_meta, obs_metas)" +
            "values ('" + txt_nome.Text + "'," +
            "'" + txt_descricao.Text + "'," +
            "'" + txt_dataInicio.Text + "'," +
            "'" + txt_dataFim.Text + "'," +
            "'" + cbo_status.Text + "'," +
            "'" + txt_obs.Text + "'," +
            "')" + "Select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(Conexao);
            SqlCommand comando = new SqlCommand(Cadastro, conexao);
            comando.CommandType = System.Data.CommandType.Text;
            SqlDataReader leitura;
            conexao.Open();

            try
            {
                leitura = comando.ExecuteReader();
                if (leitura.Read())
                {
                    MessageBox.Show("Cadastro Realizado com sucesso, Código gerado: " + leitura[0].ToString());
                    txt_codigo.Text = leitura[0].ToString();

                    bto_limpar.PerformClick();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
            finally
            {
                conexao.Close();
            }
        }

        private void bto_limpar_Click(object sender, EventArgs e)
        {
            txt_codigo.Text = "";
            txt_nome.Text = "";
            txt_descricao.Text = "";
            txt_dataInicio.Text = "";
            txt_dataFim.Text = "";
            cbo_status.SelectedIndex = -1;
            txt_obs.Text = "";
        }

        private void bto_alterar_Click(object sender, EventArgs e)
        {
            DialogResult dialogo = MessageBox.Show("Você tem certeza de que deseja alterar os dados do funcionario?", "Alteração", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dialogo == DialogResult.Cancel)
            {
                return;
            }
            else if (dialogo == DialogResult.OK)
            {
                string sql = "update meta set " +
                        "nome_meta = " + "'" + txt_nome.Text + "'," +
                        "descricao_meta =" + "'" + txt_descricao.Text + "'," +
                        "data_metas_inicio =" + "'" + txt_dataInicio.Text + "'," +
                        "data_meta_fim =" + "'" + txt_dataFim.Text + "'," +
                        "status_meta =" + "'" + cbo_status.Text + "'," +
                        "obs_meta =" + "'" + txt_obs.Text + "'" +
                        "where id_meta =" + txt_codigo.Text;

                SqlConnection conn = new SqlConnection(Conexao);
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = System.Data.CommandType.Text;

                try
                {
                    conn.Open();

                    int i = cmd.ExecuteNonQuery();
                    if (i == 1)
                    {
                        MessageBox.Show("Dados alterados com sucesso");
                        bto_limpar.PerformClick();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void bto_excluir_Click(object sender, EventArgs e)
        {
            string sql = "delete meta where id_meta =" + txt_codigo.Text;

            SqlConnection conn = new SqlConnection(Conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            conn.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Dados excluidos com sucesso");
                    bto_limpar.PerformClick();
                }
                else
                {
                    MessageBox.Show("Erro, não foi possivel excluir essa meta");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
    }

