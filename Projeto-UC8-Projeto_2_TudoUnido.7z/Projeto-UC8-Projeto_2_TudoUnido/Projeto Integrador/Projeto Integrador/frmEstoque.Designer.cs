﻿namespace Projeto_Integrador
{
    partial class frmEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_dataCadastro = new System.Windows.Forms.Label();
            this.data_cadastro = new System.Windows.Forms.MaskedTextBox();
            this.codigo_estoque = new System.Windows.Forms.NumericUpDown();
            this.pesquisa_codigo = new System.Windows.Forms.Button();
            this.data_vencimento = new System.Windows.Forms.MaskedTextBox();
            this.categoria_estoque = new System.Windows.Forms.TextBox();
            this.obs_estoque = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Status_estoque = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.estoque_descricao = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nome_estoque = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.data_gride_estoque = new System.Windows.Forms.DataGridView();
            this.txt_pesquisaDataGrid = new System.Windows.Forms.TextBox();
            this.excluir_estoque = new System.Windows.Forms.Button();
            this.Limpa_estoque = new System.Windows.Forms.Button();
            this.alterar_estoque = new System.Windows.Forms.Button();
            this.cadastrar_estoque = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.codigo_estoque)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_gride_estoque)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_dataCadastro);
            this.groupBox1.Controls.Add(this.data_cadastro);
            this.groupBox1.Controls.Add(this.codigo_estoque);
            this.groupBox1.Controls.Add(this.pesquisa_codigo);
            this.groupBox1.Controls.Add(this.data_vencimento);
            this.groupBox1.Controls.Add(this.categoria_estoque);
            this.groupBox1.Controls.Add(this.obs_estoque);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.Status_estoque);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.estoque_descricao);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nome_estoque);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(14, 5);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(361, 539);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // lbl_dataCadastro
            // 
            this.lbl_dataCadastro.AutoSize = true;
            this.lbl_dataCadastro.Location = new System.Drawing.Point(7, 162);
            this.lbl_dataCadastro.Name = "lbl_dataCadastro";
            this.lbl_dataCadastro.Size = new System.Drawing.Size(123, 20);
            this.lbl_dataCadastro.TabIndex = 25;
            this.lbl_dataCadastro.Text = "Data de cadastro";
            // 
            // data_cadastro
            // 
            this.data_cadastro.Enabled = false;
            this.data_cadastro.Location = new System.Drawing.Point(7, 186);
            this.data_cadastro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.data_cadastro.Mask = "##/##/####";
            this.data_cadastro.Name = "data_cadastro";
            this.data_cadastro.Size = new System.Drawing.Size(83, 27);
            this.data_cadastro.TabIndex = 24;
            // 
            // codigo_estoque
            // 
            this.codigo_estoque.Location = new System.Drawing.Point(7, 36);
            this.codigo_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.codigo_estoque.Name = "codigo_estoque";
            this.codigo_estoque.Size = new System.Drawing.Size(83, 27);
            this.codigo_estoque.TabIndex = 23;
            // 
            // pesquisa_codigo
            // 
            this.pesquisa_codigo.Location = new System.Drawing.Point(125, 36);
            this.pesquisa_codigo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pesquisa_codigo.Name = "pesquisa_codigo";
            this.pesquisa_codigo.Size = new System.Drawing.Size(89, 31);
            this.pesquisa_codigo.TabIndex = 22;
            this.pesquisa_codigo.Text = "Pesquisar";
            this.pesquisa_codigo.UseVisualStyleBackColor = true;
            this.pesquisa_codigo.Click += new System.EventHandler(this.pesquisa_codigo_Click);
            // 
            // data_vencimento
            // 
            this.data_vencimento.Location = new System.Drawing.Point(154, 186);
            this.data_vencimento.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.data_vencimento.Mask = "##/##/####";
            this.data_vencimento.Name = "data_vencimento";
            this.data_vencimento.Size = new System.Drawing.Size(83, 27);
            this.data_vencimento.TabIndex = 21;
            // 
            // categoria_estoque
            // 
            this.categoria_estoque.Location = new System.Drawing.Point(154, 117);
            this.categoria_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.categoria_estoque.MaxLength = 100;
            this.categoria_estoque.Name = "categoria_estoque";
            this.categoria_estoque.Size = new System.Drawing.Size(114, 27);
            this.categoria_estoque.TabIndex = 19;
            this.categoria_estoque.TextChanged += new System.EventHandler(this.categoria_estoque_TextChanged);
            // 
            // obs_estoque
            // 
            this.obs_estoque.Location = new System.Drawing.Point(7, 401);
            this.obs_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.obs_estoque.MaxLength = 255;
            this.obs_estoque.Multiline = true;
            this.obs_estoque.Name = "obs_estoque";
            this.obs_estoque.PlaceholderText = "Opcional";
            this.obs_estoque.Size = new System.Drawing.Size(235, 109);
            this.obs_estoque.TabIndex = 18;
            this.obs_estoque.TextChanged += new System.EventHandler(this.obs_estoque_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 377);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 20);
            this.label10.TabIndex = 16;
            this.label10.Text = "Obs";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // Status_estoque
            // 
            this.Status_estoque.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Status_estoque.FormattingEnabled = true;
            this.Status_estoque.Items.AddRange(new object[] {
            "Ativo",
            "Inativo"});
            this.Status_estoque.Location = new System.Drawing.Point(248, 482);
            this.Status_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Status_estoque.Name = "Status_estoque";
            this.Status_estoque.Size = new System.Drawing.Size(82, 28);
            this.Status_estoque.TabIndex = 15;
            this.Status_estoque.SelectedIndexChanged += new System.EventHandler(this.Status_estoque_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(248, 458);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "Status";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // estoque_descricao
            // 
            this.estoque_descricao.Location = new System.Drawing.Point(7, 256);
            this.estoque_descricao.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.estoque_descricao.MaxLength = 255;
            this.estoque_descricao.Multiline = true;
            this.estoque_descricao.Name = "estoque_descricao";
            this.estoque_descricao.PlaceholderText = "Descrição estoque";
            this.estoque_descricao.Size = new System.Drawing.Size(327, 113);
            this.estoque_descricao.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 232);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "Descricao";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(154, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Data de vencimento";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(154, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Categoria estoque";
            // 
            // nome_estoque
            // 
            this.nome_estoque.Location = new System.Drawing.Point(7, 117);
            this.nome_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nome_estoque.MaxLength = 100;
            this.nome_estoque.Name = "nome_estoque";
            this.nome_estoque.Size = new System.Drawing.Size(126, 27);
            this.nome_estoque.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nome do estoque";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codigo do estoque";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.data_gride_estoque);
            this.groupBox2.Controls.Add(this.txt_pesquisaDataGrid);
            this.groupBox2.Location = new System.Drawing.Point(417, 5);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(464, 333);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // data_gride_estoque
            // 
            this.data_gride_estoque.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.data_gride_estoque.Location = new System.Drawing.Point(7, 76);
            this.data_gride_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.data_gride_estoque.Name = "data_gride_estoque";
            this.data_gride_estoque.RowHeadersWidth = 51;
            this.data_gride_estoque.RowTemplate.Height = 25;
            this.data_gride_estoque.Size = new System.Drawing.Size(427, 233);
            this.data_gride_estoque.TabIndex = 2;
            this.data_gride_estoque.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.data_gride_estoque_CellContentClick);
            // 
            // txt_pesquisaDataGrid
            // 
            this.txt_pesquisaDataGrid.Location = new System.Drawing.Point(7, 25);
            this.txt_pesquisaDataGrid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_pesquisaDataGrid.Name = "txt_pesquisaDataGrid";
            this.txt_pesquisaDataGrid.PlaceholderText = "Pesquise aqui por nome";
            this.txt_pesquisaDataGrid.Size = new System.Drawing.Size(319, 27);
            this.txt_pesquisaDataGrid.TabIndex = 0;
            this.txt_pesquisaDataGrid.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // excluir_estoque
            // 
            this.excluir_estoque.Location = new System.Drawing.Point(482, 553);
            this.excluir_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.excluir_estoque.Name = "excluir_estoque";
            this.excluir_estoque.Size = new System.Drawing.Size(90, 44);
            this.excluir_estoque.TabIndex = 3;
            this.excluir_estoque.Text = "Excluir";
            this.excluir_estoque.UseVisualStyleBackColor = true;
            this.excluir_estoque.Click += new System.EventHandler(this.excluir_estoque_Click);
            // 
            // Limpa_estoque
            // 
            this.Limpa_estoque.Location = new System.Drawing.Point(247, 553);
            this.Limpa_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Limpa_estoque.Name = "Limpa_estoque";
            this.Limpa_estoque.Size = new System.Drawing.Size(86, 44);
            this.Limpa_estoque.TabIndex = 2;
            this.Limpa_estoque.Text = "Limpa";
            this.Limpa_estoque.UseVisualStyleBackColor = true;
            this.Limpa_estoque.Click += new System.EventHandler(this.button4_Click);
            // 
            // alterar_estoque
            // 
            this.alterar_estoque.Location = new System.Drawing.Point(690, 553);
            this.alterar_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.alterar_estoque.Name = "alterar_estoque";
            this.alterar_estoque.Size = new System.Drawing.Size(90, 43);
            this.alterar_estoque.TabIndex = 1;
            this.alterar_estoque.Text = "Alterar";
            this.alterar_estoque.UseVisualStyleBackColor = true;
            this.alterar_estoque.Click += new System.EventHandler(this.altera_estoque_Click);
            // 
            // cadastrar_estoque
            // 
            this.cadastrar_estoque.Location = new System.Drawing.Point(815, 553);
            this.cadastrar_estoque.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cadastrar_estoque.Name = "cadastrar_estoque";
            this.cadastrar_estoque.Size = new System.Drawing.Size(86, 41);
            this.cadastrar_estoque.TabIndex = 0;
            this.cadastrar_estoque.Text = "Cadastrar";
            this.cadastrar_estoque.UseVisualStyleBackColor = true;
            this.cadastrar_estoque.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(14, 552);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 43);
            this.button5.TabIndex = 3;
            this.button5.Text = "Sair";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // frmEstoque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.Limpa_estoque);
            this.Controls.Add(this.excluir_estoque);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.alterar_estoque);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.cadastrar_estoque);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmEstoque";
            this.Text = "Cadastro de Estoque";
            this.Load += new System.EventHandler(this.frmEstoque_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.codigo_estoque)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.data_gride_estoque)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private TextBox obs_estoque;
        private Label label10;
        private ComboBox Status_estoque;
        private Label label9;
        private TextBox estoque_descricao;
        private Label label7;
        private Label label6;
        private Label label3;
        private TextBox nome_estoque;
        private Label label2;
        private Label label1;
        private GroupBox groupBox2;
        private DataGridView data_gride_estoque;
        private TextBox txt_pesquisaDataGrid;
        private Button button5;
        private Button Limpa_estoque;
        private Button alterar_estoque;
        private Button cadastrar_estoque;
        private Button excluir_estoque;
        private MaskedTextBox data_vencimento;
        private TextBox categoria_estoque;
        private Button pesquisa_codigo;
        private NumericUpDown codigo_estoque;
        private Label lbl_dataCadastro;
        private MaskedTextBox data_cadastro;
    }
}