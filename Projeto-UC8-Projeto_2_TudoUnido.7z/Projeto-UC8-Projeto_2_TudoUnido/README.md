# Projeto-UC8

Projeto do curso de T.I do Senac com o objetivo de criar um sistema ERP

## Em progresso

- [ ] - Data Grid
  
  - [ ] funcionario(Tabela)
  
  - [ ]  relatorio(Tabela)
  
  - [ ]  estoque(Tabela)
  
  - [ ] fornecedor(Tabela)
  
  - [ ] categoria(Tabela)
  
  - [ ] produto(Tabela)   
  
  - [ ] venda(Tabela)

- [X] - Banco de dados(Correçoes)

- [ ] - Programação das telas

- [ ] - Grafico dinamico
  
  - [ ] vendas
  
  - [ ] meses
   
  - [ ] mais vendidos 

## Finalizado

- [X] - Banco de dados(base)

- [X] - Design das telas

- [ ] - 

- [ ] - 

## Créditos


