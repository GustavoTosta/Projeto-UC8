//I
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Integrador
{
    public partial class DataGrid_Base : Form
    {
        public static string Conexao = "" +
     "Data Source=localhost;" +
     "Initial Catalog=n8_miniprojeto;" +
     "User ID=sa;" +
     "Password=123456";

        public DataGrid_Base()
        {
            InitializeComponent();
        }

        private void aConexao()
        {
            try
            {
                SqlConnection conn = new SqlConnection(Conexao);
                conn.Open();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro" + ex.Message);


            }
        }

        private void CarregarIsso
        {
            string sql = "select" +
            "id_funcionario as 'ID'," +
            "nome_funcionario as 'Nome'" +
            "cpf_funcionario as 'CPF'," +
            "data_nascimento'Nascimento '," +
            "genero_funcionario'Genero'," +
            "telefone_funcionario'Telefone'," +
            "email_funcionario 'Email'," +
            "status_funcionario 'Status'," +
            "obs_funcionario 'Observa��es' "
                    "from funcionario where nome_funcionario like '%" + txtPesquisar.Text + "%'";
                    SqlConnection conn = new SqlConnection(Conexao);
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                conn.Open();

                    try
                    {
                    adapter.Fill(ds);
                    //Definir variavel de dataUsuario
                    dataUsuario.DataSource = ds.Tables[0];
                    dataUsuario.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                    dataUsuario.AutoResizeRow(0,DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader)
        } }           catch (Exception ex)
                {
            MessageBox.Show("Erro: " + ex.Message);
        }
        finally {
            conn.Close();
        }

        private void PesquisaLoad (object sender, EventArgs e)
    {

    }
        }
    }
}
